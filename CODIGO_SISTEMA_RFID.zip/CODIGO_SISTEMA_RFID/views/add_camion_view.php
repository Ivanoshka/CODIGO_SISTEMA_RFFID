<!-- conexion a la base de datos
 --><?php include("../conexionBD.php") ?>
<!-- header -->
<?php include("../includes/head.php") ?>

<body>

  <!--NAV (barra de navegacion)  -->
  <?php include("../includes/nav.php") ?>

  <main>
    <div class="h1titulo">
      <H1 class="tituloPrincipal">CAMIONES</H1>
    </div>

  </main>

  <div class="container p-4">
    <div class="row divIcon">
      <i class="large material-icons ">
        directions_bus
      </i>
    </div>
  </div>

</body>