<nav>
    <div class="nav-wrapper navBarColor">
      <a href="../views/add_camion_view.php" class="brand-logo"><i class="small material-icons right">donut_small</i></a>
      <ul class="right hide-on-med-and-down">


        <li><a href="./add_camion_view.php">Camiones</a></li>
        <li><a href="./add_llanta_view.php">LLantas <i class="material-icons right waves-effect waves-light ">add_circle_outline</i></a> </li>
        <li><a href="#!">
        <li><a href="./add_conductores_view.php">Conductores</a></li>
        <li><a href="../login.php"><i class="material-icons right waves-effect waves-light">power_settings_new</i></a> </li>

      </ul>
    </div>
  </nav>